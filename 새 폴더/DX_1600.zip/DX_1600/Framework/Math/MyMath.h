#pragma once
class MyMath
{
public:
	static int RandomInt(int min, int max);
	static float RandomFloat(float min, float max);

private:
};