#pragma once
class Machinegun : public Gun
{
};