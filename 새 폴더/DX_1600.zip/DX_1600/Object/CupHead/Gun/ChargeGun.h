#pragma once
class ChargeGun : public Gun
{
};